package com.cmdteam.amethystxray.mixin;

import com.cmdteam.amethystxray.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    // While freecam is on, mouse movement rotates the camera instead of the player.
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void axr$changeLook(double dx, double dy, CallbackInfo ci) {
        if (Freecam.active && (Object) this == MinecraftClient.getInstance().player) {
            Freecam.rotate(dx, dy);
            ci.cancel();
        }
    }
}

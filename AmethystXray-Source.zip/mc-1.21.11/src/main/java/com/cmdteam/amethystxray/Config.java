package com.cmdteam.amethystxray;

public final class Config {
    public static boolean xray = true;
    public static boolean calcite = true;
    public static final int MIN_RADIUS = 8, MAX_RADIUS = 48;
    public static final double MIN_SPEED = 0.2, MAX_SPEED = 2.0;
    public static double freecamSpeed = 0.7;
    private static int radius = 24;

    public static int radius() {
        return radius;
    }

    public static void setRadius(int r) {
        radius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, r));
    }

    private Config() {}
}

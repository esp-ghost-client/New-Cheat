package com.cmdteam.amethystxray;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Simple self-contained freecam: the camera detaches from the player and flies around. */
public final class Freecam {
    public static boolean active = false;

    private static double x, y, z, px, py, pz;
    private static float yaw, pitch;

    public static void toggle(MinecraftClient c) {
        if (active) disable(); else enable(c);
    }

    public static void enable(MinecraftClient c) {
        if (c.player == null) return;
        x = px = c.player.getX();
        y = py = c.player.getEyeY();
        z = pz = c.player.getZ();
        yaw = c.player.getYaw();
        pitch = c.player.getPitch();
        active = true;
    }

    public static void disable() {
        active = false;
    }

    public static Vec3d pos() {
        return new Vec3d(x, y, z);
    }

    public static double ix(float t) { return px + (x - px) * t; }
    public static double iy(float t) { return py + (y - py) * t; }
    public static double iz(float t) { return pz + (z - pz) * t; }
    public static float yaw() { return yaw; }
    public static float pitch() { return pitch; }

    /** Mouse look (called from the Entity mixin instead of rotating the player). */
    public static void rotate(double dx, double dy) {
        yaw += (float) (dx * 0.15);
        pitch = MathHelper.clamp(pitch + (float) (dy * 0.15), -90.0f, 90.0f);
    }

    /** Runs at the start of every client tick. */
    public static void tick(MinecraftClient c) {
        if (!active) return;
        GameOptions o = c.options;

        // The player must not move / mine / place while the camera is detached.
        KeyBinding[] block = {o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey,
                o.sneakKey, o.sprintKey, o.attackKey, o.useKey, o.pickItemKey};
        for (KeyBinding k : block) k.setPressed(false);
        while (o.attackKey.wasPressed()) { }
        while (o.useKey.wasPressed()) { }
        while (o.pickItemKey.wasPressed()) { }

        px = x; py = y; pz = z;
        if (c.currentScreen != null) return;

        long h = c.getWindow().getHandle();
        double fwd = (down(h, o.forwardKey) ? 1 : 0) - (down(h, o.backKey) ? 1 : 0);
        double str = (down(h, o.rightKey) ? 1 : 0) - (down(h, o.leftKey) ? 1 : 0);
        double vert = (down(h, o.jumpKey) ? 1 : 0) - (down(h, o.sneakKey) ? 1 : 0);
        double speed = Config.freecamSpeed * (down(h, o.sprintKey) ? 2.5 : 1.0);

        double yr = Math.toRadians(yaw);
        double fx = -Math.sin(yr), fz = Math.cos(yr);   // forward (horizontal)
        double rx = -Math.cos(yr), rz = -Math.sin(yr);  // right
        x += (fx * fwd + rx * str) * speed;
        z += (fz * fwd + rz * str) * speed;
        y += vert * speed;
    }

    private static boolean down(long window, KeyBinding k) {
        InputUtil.Key key = KeyBindingHelper.getBoundKeyOf(k);
        if (key.getCategory() != InputUtil.Type.KEYSYM) return false;
        int code = key.getCode();
        return code >= 0 && GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
    }

    private Freecam() {}
}

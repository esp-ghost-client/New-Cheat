package com.cmdteam.amethystxray.mixin;

import com.cmdteam.amethystxray.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    // After vanilla positions the camera on the player, move it to the free camera.
    @Inject(method = "update", at = @At("TAIL"))
    private void axr$update(World area, Entity focusedEntity, boolean thirdPerson, boolean inverseView,
                            float tickDelta, CallbackInfo ci) {
        if (!Freecam.active) return;
        this.setRotation(Freecam.yaw(), Freecam.pitch());
        this.setPos(Freecam.ix(tickDelta), Freecam.iy(tickDelta), Freecam.iz(tickDelta));
    }
}

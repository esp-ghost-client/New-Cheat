package com.cmdteam.amethystxray;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * X-Ray for amethyst (strong purple) and calcite (strong white). Blocks are found by scanning loaded chunks
 * and drawn as boxes on the HUD, projected through walls.
 */
public final class XrayRenderer {
    private static final Set<Block> AMETHYST = Set.of(
            Blocks.AMETHYST_BLOCK,
            Blocks.BUDDING_AMETHYST,
            Blocks.AMETHYST_CLUSTER,
            Blocks.LARGE_AMETHYST_BUD,
            Blocks.MEDIUM_AMETHYST_BUD,
            Blocks.SMALL_AMETHYST_BUD);

    private static final int PURPLE = 0xB300FF;
    private static final int WHITE = 0xFFFFFF;

    public record Hit(BlockPos pos, boolean white) {}

    /** calcite first, amethyst last, so amethyst is drawn on top */
    public static volatile List<Hit> found = List.of();
    private static volatile int amethystCount = 0, calciteCount = 0;
    private static double nearest = -1;

    // player eye position, recorded every tick so we can interpolate smoothly between ticks
    private static double pex, pey, pez, cex, cey, cez;
    private static long tickNanos = System.nanoTime();
    private static boolean hasPrev = false;

    public static void onTick(MinecraftClient c) {
        if (c.player == null) return;
        pex = cex; pey = cey; pez = cez;
        cex = c.player.getX();
        cey = c.player.getEyeY();
        cez = c.player.getZ();
        if (!hasPrev) {
            pex = cex; pey = cey; pez = cez;
            hasPrev = true;
        }
        tickNanos = System.nanoTime();
    }

    private static float progress() {
        return (float) Math.min(1.0, Math.max(0.0, (System.nanoTime() - tickNanos) / 50_000_000.0));
    }

    private static double dist2(BlockPos p, Vec3d o) {
        double dx = p.getX() + 0.5 - o.x, dy = p.getY() + 0.5 - o.y, dz = p.getZ() + 0.5 - o.z;
        return dx * dx + dy * dy + dz * dz;
    }

    private static boolean isTarget(BlockState s) {
        Block b = s.getBlock();
        return AMETHYST.contains(b) || (Config.calcite && b == Blocks.CALCITE);
    }

    /** Scan loaded chunks around the camera (or the player). */
    public static void scan(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            found = List.of();
            return;
        }
        Vec3d o = Freecam.active ? Freecam.pos() : new Vec3d(c.player.getX(), c.player.getY(), c.player.getZ());
        int r = Config.radius();
        int ox = (int) Math.floor(o.x), oy = (int) Math.floor(o.y), oz = (int) Math.floor(o.z);
        double r2 = (double) r * r;
        List<BlockPos> ame = new ArrayList<>();
        List<BlockPos> cal = new ArrayList<>();

        for (int cx = (ox - r) >> 4; cx <= (ox + r) >> 4; cx++) {
            for (int cz = (oz - r) >> 4; cz <= (oz + r) >> 4; cz++) {
                Chunk chunk = c.world.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection s = sections[i];
                    if (s == null || s.isEmpty() || !s.hasAny(XrayRenderer::isTarget)) continue;
                    int baseY = chunk.getBottomY() + i * 16;
                    if (baseY + 15 < oy - r || baseY > oy + r) continue;
                    for (int ly = 0; ly < 16; ly++) {
                        for (int lz = 0; lz < 16; lz++) {
                            for (int lx = 0; lx < 16; lx++) {
                                Block b = s.getBlockState(lx, ly, lz).getBlock();
                                boolean isAme = AMETHYST.contains(b);
                                boolean isCal = Config.calcite && b == Blocks.CALCITE;
                                if (!isAme && !isCal) continue;
                                int wx = (cx << 4) + lx, wy = baseY + ly, wz = (cz << 4) + lz;
                                double dx = wx + 0.5 - o.x, dy = wy + 0.5 - o.y, dz = wz + 0.5 - o.z;
                                if (dx * dx + dy * dy + dz * dz > r2) continue;
                                if (isAme) ame.add(new BlockPos(wx, wy, wz)); else cal.add(new BlockPos(wx, wy, wz));
                            }
                        }
                    }
                }
            }
        }

        Comparator<BlockPos> byDist = Comparator.comparingDouble((BlockPos p) -> dist2(p, o));
        ame.sort(byDist);
        cal.sort(byDist);
        if (ame.size() > 400) ame = new ArrayList<>(ame.subList(0, 400));
        if (cal.size() > 300) cal = new ArrayList<>(cal.subList(0, 300));

        nearest = ame.isEmpty() ? -1 : Math.sqrt(dist2(ame.get(0), o));
        amethystCount = ame.size();
        calciteCount = cal.size();

        List<Hit> out = new ArrayList<>(ame.size() + cal.size());
        for (BlockPos p : cal) out.add(new Hit(p, true));
        for (BlockPos p : ame) out.add(new Hit(p, false));
        found = out;
    }

    /** HUD callback. */
    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null || c.player == null || c.options.hudHidden) return;

        if (Freecam.active) {
            ctx.drawTextWithShadow(c.textRenderer, "FREECAM", 6, 18, 0xFFFFFF);
        }
        if (!Config.xray) return;

        List<Hit> list = found;
        String info;
        if (list.isEmpty()) {
            info = "Amethyst X-Ray: nothing within " + Config.radius() + " blocks";
        } else {
            info = "Amethyst X-Ray: " + amethystCount + " amethyst"
                    + (Config.calcite ? " + " + calciteCount + " calcite" : "")
                    + (nearest >= 0 ? ", nearest " + Math.round(nearest) + " blocks" : "");
        }
        ctx.drawTextWithShadow(c.textRenderer, info, 6, 6, 0xD58CFF);
        if (list.isEmpty()) return;

        float prog = progress();
        Vec3d cp;
        double yawDeg, pitchDeg;
        if (Freecam.active) {
            cp = new Vec3d(Freecam.ix(prog), Freecam.iy(prog), Freecam.iz(prog));
            yawDeg = Freecam.yaw();
            pitchDeg = Freecam.pitch();
        } else {
            cp = new Vec3d(pex + (cex - pex) * prog, pey + (cey - pey) * prog, pez + (cez - pez) * prog);
            yawDeg = c.player.getYaw();
            pitchDeg = c.player.getPitch();
        }
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);

        // camera basis (Minecraft: yaw 0 looks toward +Z)
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / (double) h;
        double maxDist = Config.radius();

        for (Hit hit : list) {
            BlockPos p = hit.pos();

            double cdx = p.getX() + 0.5 - cp.x, cdy = p.getY() + 0.5 - cp.y, cdz = p.getZ() + 0.5 - cp.z;
            double cz = cdx * fx + cdy * fy + cdz * fz;
            if (cz <= 0.1) continue; // behind the camera

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            for (int i = 0; i < 8; i++) {
                double dx = p.getX() + (i & 1) - cp.x;
                double dy = p.getY() + ((i >> 1) & 1) - cp.y;
                double dz = p.getZ() + ((i >> 2) & 1) - cp.z;
                double vx = dx * rx + dy * ry + dz * rz;
                double vy = dx * ux + dy * uy + dz * uz;
                double vz = Math.max(dx * fx + dy * fy + dz * fz, 0.05);
                double sx = (vx / (vz * tanHalf * aspect) * 0.5 + 0.5) * w;
                double sy = (0.5 - vy / (vz * tanHalf) * 0.5) * h;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }

            int x1 = (int) Math.floor(minX), y1 = (int) Math.floor(minY);
            int x2 = (int) Math.ceil(maxX), y2 = (int) Math.ceil(maxY);
            if (x2 - x1 < 5) { x1 -= 2; x2 += 3; }
            if (y2 - y1 < 5) { y1 -= 2; y2 += 3; }
            if (x2 < 0 || y2 < 0 || x1 > w || y1 > h) continue;
            if (x2 - x1 > w * 3 || y2 - y1 > h * 3) continue;

            double dist = Math.sqrt(cdx * cdx + cdy * cdy + cdz * cdz);
            double near = Math.max(0.0, 1.0 - dist / maxDist);
            int rgb = hit.white() ? WHITE : PURPLE;
            int fillAlpha = hit.white() ? (int) (45 + 105 * near) : (int) (55 + 120 * near);
            int fill = (fillAlpha << 24) | rgb;
            int border = 0xFF000000 | rgb;

            ctx.fill(x1, y1, x2, y2, fill);
            ctx.fill(x1, y1, x2, y1 + 1, border);
            ctx.fill(x1, y2 - 1, x2, y2, border);
            ctx.fill(x1, y1, x1 + 1, y2, border);
            ctx.fill(x2 - 1, y1, x2, y2, border);
        }
    }

    private XrayRenderer() {}
}

package com.cmdteam.amethystxray;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * X-Ray for amethyst only. Nearby amethyst blocks/clusters are found by scanning loaded chunks and
 * are drawn as strong purple boxes on the HUD, projected through walls.
 */
public final class XrayRenderer {
    private static final Set<Block> TARGETS = Set.of(
            Blocks.AMETHYST_BLOCK,
            Blocks.BUDDING_AMETHYST,
            Blocks.AMETHYST_CLUSTER,
            Blocks.LARGE_AMETHYST_BUD,
            Blocks.MEDIUM_AMETHYST_BUD,
            Blocks.SMALL_AMETHYST_BUD);

    private static final int PURPLE = 0xB300FF;
    private static final int MAX_DRAW = 300;

    public static volatile List<BlockPos> found = List.of();
    private static double nearest = -1;

    private static boolean isTarget(BlockState s) {
        return TARGETS.contains(s.getBlock());
    }

    /** Scan loaded chunks around the camera (or the player) for amethyst. */
    public static void scan(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            found = List.of();
            return;
        }
        Vec3d o = Freecam.active ? Freecam.pos() : c.player.getPos();
        int r = Config.radius();
        int ox = (int) Math.floor(o.x), oy = (int) Math.floor(o.y), oz = (int) Math.floor(o.z);
        double r2 = (double) r * r;
        List<BlockPos> out = new ArrayList<>();

        for (int cx = (ox - r) >> 4; cx <= (ox + r) >> 4; cx++) {
            for (int cz = (oz - r) >> 4; cz <= (oz + r) >> 4; cz++) {
                Chunk chunk = c.world.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection s = sections[i];
                    if (s == null || s.isEmpty() || !s.hasAny(XrayRenderer::isTarget)) continue;
                    int baseY = chunk.getBottomY() + i * 16;
                    if (baseY + 15 < oy - r || baseY > oy + r) continue;
                    for (int ly = 0; ly < 16; ly++) {
                        for (int lz = 0; lz < 16; lz++) {
                            for (int lx = 0; lx < 16; lx++) {
                                if (!isTarget(s.getBlockState(lx, ly, lz))) continue;
                                int wx = (cx << 4) + lx, wy = baseY + ly, wz = (cz << 4) + lz;
                                double dx = wx + 0.5 - o.x, dy = wy + 0.5 - o.y, dz = wz + 0.5 - o.z;
                                if (dx * dx + dy * dy + dz * dz > r2) continue;
                                out.add(new BlockPos(wx, wy, wz));
                            }
                        }
                    }
                }
            }
        }

        out.sort(Comparator.comparingDouble(p -> p.getSquaredDistance(o)));
        if (out.size() > 400) out = new ArrayList<>(out.subList(0, 400));
        nearest = out.isEmpty() ? -1 : Math.sqrt(out.get(0).getSquaredDistance(o));
        found = out;
    }

    /** HUD callback. */
    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null || c.player == null || c.options.hudHidden) return;

        if (Freecam.active) {
            ctx.drawTextWithShadow(c.textRenderer, "FREECAM", 6, 18, 0xFFFFFF);
        }
        if (!Config.xray) return;

        List<BlockPos> list = found;
        String info = list.isEmpty()
                ? "Amethyst X-Ray: none within " + Config.radius() + " blocks"
                : "Amethyst X-Ray: " + list.size() + " found, nearest " + Math.round(nearest) + " blocks";
        ctx.drawTextWithShadow(c.textRenderer, info, 6, 6, 0xD58CFF);
        if (list.isEmpty()) return;

        Camera cam = c.gameRenderer.getCamera();
        Vec3d cp = cam.getPos();
        double yaw = Math.toRadians(cam.getYaw());
        double pitch = Math.toRadians(cam.getPitch());

        // camera basis (Minecraft: yaw 0 looks toward +Z)
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / (double) h;
        double maxDist = Config.radius();

        int drawn = 0;
        for (BlockPos p : list) {
            if (drawn >= MAX_DRAW) break;

            double cdx = p.getX() + 0.5 - cp.x, cdy = p.getY() + 0.5 - cp.y, cdz = p.getZ() + 0.5 - cp.z;
            double cz = cdx * fx + cdy * fy + cdz * fz;
            if (cz <= 0.1) continue; // behind the camera

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            for (int i = 0; i < 8; i++) {
                double dx = p.getX() + (i & 1) - cp.x;
                double dy = p.getY() + ((i >> 1) & 1) - cp.y;
                double dz = p.getZ() + ((i >> 2) & 1) - cp.z;
                double vx = dx * rx + dy * ry + dz * rz;
                double vy = dx * ux + dy * uy + dz * uz;
                double vz = Math.max(dx * fx + dy * fy + dz * fz, 0.05);
                double sx = (vx / (vz * tanHalf * aspect) * 0.5 + 0.5) * w;
                double sy = (0.5 - vy / (vz * tanHalf) * 0.5) * h;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }

            int x1 = (int) Math.floor(minX), y1 = (int) Math.floor(minY);
            int x2 = (int) Math.ceil(maxX), y2 = (int) Math.ceil(maxY);
            if (x2 - x1 < 5) { x1 -= 2; x2 += 3; }
            if (y2 - y1 < 5) { y1 -= 2; y2 += 3; }
            if (x2 < 0 || y2 < 0 || x1 > w || y1 > h) continue;
            if (x2 - x1 > w * 3 || y2 - y1 > h * 3) continue;

            double dist = Math.sqrt(cdx * cdx + cdy * cdy + cdz * cdz);
            double near = Math.max(0.0, 1.0 - dist / maxDist);
            int fillAlpha = (int) (55 + 120 * near);
            int fill = (fillAlpha << 24) | PURPLE;
            int border = 0xFF000000 | PURPLE;

            ctx.fill(x1, y1, x2, y2, fill);
            ctx.fill(x1, y1, x2, y1 + 1, border);
            ctx.fill(x1, y2 - 1, x2, y2, border);
            ctx.fill(x1, y1, x1 + 1, y2, border);
            ctx.fill(x2 - 1, y1, x2, y2, border);
            drawn++;
        }
    }

    private XrayRenderer() {}
}

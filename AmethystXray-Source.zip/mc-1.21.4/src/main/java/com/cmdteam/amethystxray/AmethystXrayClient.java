package com.cmdteam.amethystxray;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class AmethystXrayClient implements ClientModInitializer {
    public static KeyBinding menuKey, xrayKey, freecamKey;
    private static int ticks = 0;

    private static final String CATEGORY = "key.categories.amethyst_xray";

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.amethyst_xray.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_ENTER, CATEGORY));
        xrayKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.amethyst_xray.xray", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY));
        freecamKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.amethyst_xray.freecam", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY));

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                Freecam.disable();
                return;
            }
            Freecam.tick(client);
        });
        ClientTickEvents.END_CLIENT_TICK.register(AmethystXrayClient::endTick);
        HudRenderCallback.EVENT.register(XrayRenderer::render);
    }

    private static void endTick(MinecraftClient c) {
        if (c.player == null || c.world == null) return;
        XrayRenderer.onTick(c);

        while (menuKey.wasPressed()) {
            if (c.currentScreen == null) c.setScreen(new AxrScreen());
        }
        while (xrayKey.wasPressed()) {
            Config.xray = !Config.xray;
            if (Config.xray) XrayRenderer.scan(c);
            c.player.sendMessage(Text.literal("Amethyst X-Ray: " + (Config.xray ? "ON" : "OFF")), true);
        }
        while (freecamKey.wasPressed()) {
            Freecam.toggle(c);
            c.player.sendMessage(Text.literal("Freecam: " + (Freecam.active ? "ON" : "OFF")), true);
        }

        if (Config.xray) {
            if (++ticks % 10 == 0) XrayRenderer.scan(c);
        } else {
            XrayRenderer.found = List.of();
        }
    }
}

# Amethyst X-Ray (Fabric) — by ItsBloodyStar | CMD Team

Two folders, one per version:
- `mc-1.21.4/`  -> Fabric 1.21.4
- `mc-1.21.11/` -> Fabric 1.21.11

Both need Fabric API. Java 21.

## Build on GitHub
1. Create a repo, upload EVERYTHING in this folder (keep `.github`, `mc-1.21.4`, `mc-1.21.11` at the repo root).
2. Open the Actions tab -> run "Build Amethyst X-Ray" (or just push).
3. Download the artifacts `AmethystXray-mc-1.21.4` and `AmethystXray-mc-1.21.11` -> jar inside.

## Keys (all rebindable in Controls)
- Enter : open the legendary menu (Freecam switch, X-Ray switch, scan range slider, freecam speed slider)
- X     : quick X-Ray on/off
- Freecam quick toggle: unbound by default

## Freecam
WASD fly, Space up, Shift down, Sprint = faster. Mouse looks. The player stays in place and can't mine/place while freecam is on.

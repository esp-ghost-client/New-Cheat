package com.cmdteam.amethystxray;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Custom-drawn "legendary" amethyst menu: glowing panel, animated switches, sliders, floating shards. */
public class AxrScreen extends Screen {
    private static final int PW = 264, PH = 262;
    private static final int GOLD = 0xFFFFC857, PURPLE = 0xFF9D4EDD, LIGHT = 0xFFC77DFF;
    private static final int TEXT = 0xFFF3EAFF, DIM = 0xFF9E8FB8, MINT = 0xFF7CFFB2;

    private final long openTime = System.currentTimeMillis();
    private long lastFrame = System.nanoTime();
    private long closeAt = 0;
    private float swFreecam = Freecam.active ? 1f : 0f;
    private float swXray = Config.xray ? 1f : 0f;
    private int dragging = 0;
    private int mx, my;
    private float fade = 1f;
    private int px0, py0;

    public AxrScreen() {
        super(Text.literal("Amethyst X-Ray"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------------ input logic
    private static boolean in(double x, double y, int bx, int by, int bw, int bh) {
        return x >= bx && x < bx + bw && y >= by && y < by + bh;
    }

    private void press(double x, double y) {
        int bx = px0 + 14, bw = PW - 28;
        if (in(x, y, bx, py0 + 54, bw, 44)) {
            Freecam.toggle(MinecraftClient.getInstance());
            if (Freecam.active) closeAt = System.currentTimeMillis() + 320; // close so you can fly right away
        } else if (in(x, y, bx, py0 + 104, bw, 44)) {
            Config.xray = !Config.xray;
            if (Config.xray) XrayRenderer.scan(MinecraftClient.getInstance());
        } else if (in(x, y, px0 + 10, py0 + 168, PW - 20, 18)) {
            dragging = 1;
            applyDrag(x);
        } else if (in(x, y, px0 + 10, py0 + 202, PW - 20, 18)) {
            dragging = 2;
            applyDrag(x);
        }
    }

    private void drag(double x) {
        if (dragging != 0) applyDrag(x);
    }

    private void release() {
        if (dragging == 1) XrayRenderer.scan(MinecraftClient.getInstance());
        dragging = 0;
    }

    private void applyDrag(double x) {
        double t = Math.max(0.0, Math.min(1.0, (x - (px0 + 16)) / (PW - 32)));
        if (dragging == 1) {
            Config.setRadius((int) Math.round(Config.MIN_RADIUS + t * (Config.MAX_RADIUS - Config.MIN_RADIUS)));
        } else if (dragging == 2) {
            Config.freecamSpeed = Math.round((Config.MIN_SPEED + t * (Config.MAX_SPEED - Config.MIN_SPEED)) * 10.0) / 10.0;
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        press(click.x(), click.y());
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        drag(click.x());
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        release();
        return true;
    }

    // ------------------------------------------------------------------ drawing helpers
    private int fx(int argb) {
        int a = (int) (((argb >>> 24) & 0xFF) * fade);
        return (Math.max(a, 0) << 24) | (argb & 0xFFFFFF);
    }

    private static int lerp(int c1, int c2, double t) {
        int a = (int) (((c1 >>> 24) & 0xFF) * (1 - t) + ((c2 >>> 24) & 0xFF) * t);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void diamond(DrawContext g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = r - Math.abs(dy);
            g.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    private void txt(DrawContext g, String s, int x, int y, int color) {
        g.drawTextWithShadow(this.textRenderer, s, x, y, fx(color));
    }

    private Text bold(String s) {
        return Text.literal(s).formatted(Formatting.BOLD);
    }

    private void txtB(DrawContext g, String s, int x, int y, int color) {
        g.drawTextWithShadow(this.textRenderer, bold(s), x, y, fx(color));
    }

    private int chip(DrawContext g, String key, String label, int x, int y) {
        int kw = this.textRenderer.getWidth(key) + 8;
        g.fill(x, y, x + kw, y + 12, fx(0xFF2B1F45));
        g.drawBorder(x, y, kw, 12, fx(0xFF5A3A8C));
        txt(g, key, x + 4, y + 2, LIGHT);
        txt(g, label, x + kw + 4, y + 2, DIM);
        return kw + 4 + this.textRenderer.getWidth(label);
    }

    private void toggle(DrawContext g, int x, int y, float t) {
        int track = lerp(0xFF2A2236, PURPLE, t);
        g.fill(x + 1, y, x + 35, y + 14, fx(track));
        g.fill(x, y + 1, x + 36, y + 13, fx(track));
        if (t > 0.5f) g.fill(x + 2, y + 1, x + 34, y + 2, fx(0x55FFFFFF));
        int kx = x + 2 + Math.round(t * 20);
        g.fill(kx, y + 2, kx + 12, y + 12, fx(0xFFFFFFFF));
        g.fill(kx + 1, y + 11, kx + 11, y + 12, fx(0xFFD9C8F0));
    }

    private void card(DrawContext g, int x, int y, int w, int unused, String name, String desc, boolean on, float sw, boolean freecamIcon) {
        boolean hover = in(mx, my, x, y, w, 44);
        g.fill(x, y, x + w, y + 44, fx(hover ? 0xFF241639 : 0xFF1B1129));
        g.drawBorder(x, y, w, 44, fx(on ? 0xFF6B3FA8 : 0xFF33264B));
        g.fill(x, y, x + 3, y + 44, fx(on ? PURPLE : 0xFF3A2D52));

        // icon plate
        g.fill(x + 8, y + 8, x + 36, y + 36, fx(0xFF120A1F));
        g.drawBorder(x + 8, y + 8, 28, 28, fx(on ? LIGHT : 0xFF4A3A66));
        int ic = on ? LIGHT : 0xFF6E5F8A;
        int ix = x + 8, iy = y + 8;
        if (freecamIcon) {
            g.fill(ix + 7, iy + 10, ix + 21, iy + 20, fx(ic));
            g.fill(ix + 10, iy + 8, ix + 14, iy + 10, fx(ic));
            g.fill(ix + 12, iy + 12, ix + 16, iy + 18, fx(0xFF120A1F));
            g.fill(ix + 13, iy + 13, ix + 15, iy + 17, fx(on ? 0xFFFFFFFF : 0xFF4A3A66));
        } else {
            diamond(g, ix + 14, iy + 14, 9, fx(ic));
            diamond(g, ix + 14, iy + 14, 4, fx(0xFF120A1F));
            diamond(g, ix + 14, iy + 14, 1, fx(on ? 0xFFFFFFFF : 0xFF4A3A66));
        }

        txtB(g, name, x + 44, y + 9, TEXT);
        txt(g, desc, x + 44, y + 24, DIM);

        String status = on ? "ACTIVE" : "OFF";
        txt(g, status, x + w - 46 - this.textRenderer.getWidth(status), y + 8, on ? MINT : 0xFF6E5F8A);
        toggle(g, x + w - 46, y + 15, sw);
    }

    private void slider(DrawContext g, String label, String value, int x, int y, int w, float t) {
        txt(g, label, x, y - 14, DIM);
        txtB(g, value, x + w - this.textRenderer.getWidth(bold(value)), y - 14, LIGHT);
        g.fill(x, y, x + w, y + 4, fx(0xFF2A2040));
        int fw = (int) (w * t);
        g.fill(x, y, x + fw, y + 4, fx(PURPLE));
        g.fill(x, y, x + fw, y + 1, fx(LIGHT));
        int kx = x + fw;
        diamond(g, kx, y + 2, 6, fx(0x55C77DFF));
        diamond(g, kx, y + 2, 5, fx(0xFF2A1450));
        diamond(g, kx, y + 2, 4, fx(LIGHT));
        diamond(g, kx, y + 2, 2, fx(0xFFFFFFFF));
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        this.mx = mouseX;
        this.my = mouseY;
        long nowMs = System.currentTimeMillis();
        long nowNs = System.nanoTime();
        float dt = Math.min(0.1f, (nowNs - lastFrame) / 1_000_000_000f);
        lastFrame = nowNs;

        if (closeAt != 0 && nowMs >= closeAt) {
            this.close();
            return;
        }

        float t = Math.min(1f, (nowMs - openTime) / 260f);
        float ease = 1f - (1f - t) * (1f - t) * (1f - t);
        fade = ease;
        double pulse = 0.5 + 0.5 * Math.sin(nowMs / 650.0);

        swFreecam += ((Freecam.active ? 1f : 0f) - swFreecam) * Math.min(1f, dt * 14f);
        swXray += ((Config.xray ? 1f : 0f) - swXray) * Math.min(1f, dt * 14f);

        // dim backdrop
        g.fillGradient(0, 0, this.width, this.height, (int) (0xB0 * fade) << 24 | 0x0A0414, (int) (0xD0 * fade) << 24 | 0x020006);
        if (fade < 0.08f) return;

        px0 = (this.width - PW) / 2;
        py0 = (this.height - PH) / 2;
        int px = px0;
        int py = py0 + Math.round((1f - ease) * 14f);

        // soft outer glow
        for (int k = 4; k >= 1; k--) {
            int a = (int) ((20 - 4 * k) * (0.6 + 0.4 * pulse));
            g.fill(px - k * 2, py - k * 2, px + PW + k * 2, py + PH + k * 2, fx((a << 24) | 0x9D4EDD));
        }
        // panel
        g.fillGradient(px, py, px + PW, py + PH, fx(0xF2170B2C), fx(0xF20A0618));
        g.fillGradient(px + 1, py + 2, px + PW - 1, py + 46, fx(0x48B266FF), fx(0x00000000));
        g.drawBorder(px, py, PW, PH, fx(lerp(0xFF6B3FA8, 0xFFC77DFF, pulse)));
        g.fill(px + 1, py + 1, px + PW - 1, py + 2, fx(0x66FFFFFF));

        // gold corner marks
        g.fill(px - 1, py - 1, px + 10, py, fx(GOLD));
        g.fill(px - 1, py - 1, px, py + 10, fx(GOLD));
        g.fill(px + PW - 10, py - 1, px + PW + 1, py, fx(GOLD));
        g.fill(px + PW, py - 1, px + PW + 1, py + 10, fx(GOLD));
        g.fill(px - 1, py + PH, px + 10, py + PH + 1, fx(GOLD));
        g.fill(px - 1, py + PH - 10, px, py + PH + 1, fx(GOLD));
        g.fill(px + PW - 10, py + PH, px + PW + 1, py + PH + 1, fx(GOLD));
        g.fill(px + PW, py + PH - 10, px + PW + 1, py + PH + 1, fx(GOLD));

        // floating shards
        for (int i = 0; i < 16; i++) {
            int sx = px + 10 + (int) ((i * 7919L * 31L) % (PW - 20));
            double speed = 0.010 + (i % 5) * 0.005;
            int sy = py + PH - (int) ((nowMs * speed + i * 53) % PH);
            if (sy < py + 6 || sy > py + PH - 6) continue;
            int r = (i % 3 == 0) ? 2 : 1;
            diamond(g, sx, sy, r, fx(i % 4 == 0 ? 0x55FFC857 : 0x55C77DFF));
        }

        // header
        String title = "A M E T H Y S T   X - R A Y";
        int tw = this.textRenderer.getWidth(bold(title));
        txtB(g, title, px + (PW - tw) / 2, py + 12, TEXT);
        String sub = "LEGENDARY EDITION";
        int sw = this.textRenderer.getWidth(sub);
        txt(g, sub, px + (PW - sw) / 2, py + 27, GOLD);
        diamond(g, px + (PW - sw) / 2 - 10, py + 31, 3, fx(GOLD));
        diamond(g, px + (PW + sw) / 2 + 10, py + 31, 3, fx(GOLD));
        diamond(g, px + 22, py + 22, 6, fx(0x66C77DFF));
        diamond(g, px + 22, py + 22, 4, fx(LIGHT));
        diamond(g, px + 22, py + 22, 1, fx(0xFFFFFFFF));
        diamond(g, px + PW - 23, py + 22, 6, fx(0x66C77DFF));
        diamond(g, px + PW - 23, py + 22, 4, fx(LIGHT));
        diamond(g, px + PW - 23, py + 22, 1, fx(0xFFFFFFFF));
        g.fill(px + 14, py + 44, px + PW - 14, py + 45, fx(0x66B266FF));

        // cards
        card(g, px + 14, py + 54, PW - 28, 0, "FREECAM", "Detach the camera and scout around", Freecam.active, swFreecam, true);
        card(g, px + 14, py + 104, PW - 28, 0, "X-RAY", "Amethyst glows through the walls", Config.xray, swXray, false);

        // sliders
        float rt = (Config.radius() - Config.MIN_RADIUS) / (float) (Config.MAX_RADIUS - Config.MIN_RADIUS);
        slider(g, "SCAN RANGE", Config.radius() + " blocks", px + 16, py + 174, PW - 32, rt);
        float st = (float) ((Config.freecamSpeed - Config.MIN_SPEED) / (Config.MAX_SPEED - Config.MIN_SPEED));
        slider(g, "FREECAM SPEED", String.format("%.1fx", Config.freecamSpeed), px + 16, py + 208, PW - 32, st);

        // footer
        g.fill(px + 14, py + PH - 44, px + PW - 14, py + PH - 43, fx(0x44B266FF));
        int total = this.textRenderer.getWidth("ENTER") + 8 + 4 + this.textRenderer.getWidth("Menu")
                + this.textRenderer.getWidth("X") + 8 + 4 + this.textRenderer.getWidth("X-Ray")
                + this.textRenderer.getWidth("ESC") + 8 + 4 + this.textRenderer.getWidth("Close") + 20;
        int cx = px + (PW - total) / 2;
        int cy = py + PH - 38;
        cx += chip(g, "ENTER", "Menu", cx, cy) + 10;
        cx += chip(g, "X", "X-Ray", cx, cy) + 10;
        chip(g, "ESC", "Close", cx, cy);

        String credit = "CMD Team  |  ItsBloodyStar";
        txt(g, credit, px + (PW - this.textRenderer.getWidth(credit)) / 2, py + PH - 20, 0xFF6E5F8A);
    }
}
